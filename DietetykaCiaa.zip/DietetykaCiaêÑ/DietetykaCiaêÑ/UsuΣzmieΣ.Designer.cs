﻿namespace DietetykaCiałą
{
    partial class Usuńzmień
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.PlatnoscTb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BmiCb = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.PlecCb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.WiekTb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ObwodTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.WagaTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.NameTb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.CzlonkowieDGV = new System.Windows.Forms.DataGridView();
            this.Usun = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CzlonkowieDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.button4.Location = new System.Drawing.Point(498, 436);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 27);
            this.button4.TabIndex = 37;
            this.button4.Text = "Cofnij wcześniej";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(97, 433);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 28);
            this.button3.TabIndex = 36;
            this.button3.Text = "Cofnij";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(184, 433);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 28);
            this.button2.TabIndex = 35;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(9, 433);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 28);
            this.button1.TabIndex = 34;
            this.button1.Text = "Dodaj";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.Orange;
            this.label8.Location = new System.Drawing.Point(18, 249);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(211, 26);
            this.label8.TabIndex = 33;
            this.label8.Text = "Miesięczna Płatność";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // PlatnoscTb
            // 
            this.PlatnoscTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.PlatnoscTb.Location = new System.Drawing.Point(17, 279);
            this.PlatnoscTb.Margin = new System.Windows.Forms.Padding(2);
            this.PlatnoscTb.Name = "PlatnoscTb";
            this.PlatnoscTb.Size = new System.Drawing.Size(204, 26);
            this.PlatnoscTb.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.Orange;
            this.label7.Location = new System.Drawing.Point(12, 365);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 26);
            this.label7.TabIndex = 31;
            this.label7.Text = "BMI";
            // 
            // BmiCb
            // 
            this.BmiCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BmiCb.FormattingEnabled = true;
            this.BmiCb.Items.AddRange(new object[] {
            "16,0   wygłodzenie",
            "16,0 – 16,9   wychudzenie",
            "17,0 - 18,5   niedowaga",
            "18,5–24,9 waga prawidłowa",
            "25,0–29,9\tnadwaga",
            "30,0–34,9\totyłość I stopnia",
            "35,0–39,9\totyłość II stopnia",
            "≥40   otyłość III stopnia"});
            this.BmiCb.Location = new System.Drawing.Point(14, 395);
            this.BmiCb.Margin = new System.Windows.Forms.Padding(2);
            this.BmiCb.Name = "BmiCb";
            this.BmiCb.Size = new System.Drawing.Size(204, 28);
            this.BmiCb.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(18, 307);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 26);
            this.label6.TabIndex = 29;
            this.label6.Text = "Płeć";
            // 
            // PlecCb
            // 
            this.PlecCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PlecCb.FormattingEnabled = true;
            this.PlecCb.Items.AddRange(new object[] {
            "Mężczyzna",
            "Kobieta"});
            this.PlecCb.Location = new System.Drawing.Point(17, 335);
            this.PlecCb.Margin = new System.Windows.Forms.Padding(2);
            this.PlecCb.Name = "PlecCb";
            this.PlecCb.Size = new System.Drawing.Size(92, 28);
            this.PlecCb.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.Orange;
            this.label5.Location = new System.Drawing.Point(12, 191);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 26);
            this.label5.TabIndex = 27;
            this.label5.Text = "Wiek";
            // 
            // WiekTb
            // 
            this.WiekTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.WiekTb.Location = new System.Drawing.Point(14, 221);
            this.WiekTb.Margin = new System.Windows.Forms.Padding(2);
            this.WiekTb.Name = "WiekTb";
            this.WiekTb.Size = new System.Drawing.Size(92, 26);
            this.WiekTb.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.Orange;
            this.label4.Location = new System.Drawing.Point(9, 132);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 26);
            this.label4.TabIndex = 25;
            this.label4.Text = "Obwód ";
            // 
            // ObwodTb
            // 
            this.ObwodTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ObwodTb.Location = new System.Drawing.Point(14, 162);
            this.ObwodTb.Margin = new System.Windows.Forms.Padding(2);
            this.ObwodTb.Name = "ObwodTb";
            this.ObwodTb.Size = new System.Drawing.Size(92, 26);
            this.ObwodTb.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Orange;
            this.label3.Location = new System.Drawing.Point(12, 66);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 26);
            this.label3.TabIndex = 23;
            this.label3.Text = "Waga";
            // 
            // WagaTb
            // 
            this.WagaTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.WagaTb.Location = new System.Drawing.Point(14, 104);
            this.WagaTb.Margin = new System.Windows.Forms.Padding(2);
            this.WagaTb.Name = "WagaTb";
            this.WagaTb.Size = new System.Drawing.Size(92, 26);
            this.WagaTb.TabIndex = 22;
            this.WagaTb.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.Orange;
            this.label2.Location = new System.Drawing.Point(12, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 26);
            this.label2.TabIndex = 21;
            this.label2.Text = "Imię członka";
            // 
            // NameTb
            // 
            this.NameTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.NameTb.Location = new System.Drawing.Point(14, 37);
            this.NameTb.Margin = new System.Windows.Forms.Padding(2);
            this.NameTb.Name = "NameTb";
            this.NameTb.Size = new System.Drawing.Size(238, 26);
            this.NameTb.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(873, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 20);
            this.label1.TabIndex = 39;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label9.Location = new System.Drawing.Point(436, 7);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(249, 24);
            this.label9.TabIndex = 40;
            this.label9.Text = "Zaktualizuj lub usuń członka";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label10.Location = new System.Drawing.Point(466, 37);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 13);
            this.label10.TabIndex = 41;
            this.label10.Text = "Kliknij na członka by został usunięty";
            // 
            // CzlonkowieDGV
            // 
            this.CzlonkowieDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CzlonkowieDGV.Location = new System.Drawing.Point(285, 52);
            this.CzlonkowieDGV.Margin = new System.Windows.Forms.Padding(2);
            this.CzlonkowieDGV.Name = "CzlonkowieDGV";
            this.CzlonkowieDGV.RowHeadersWidth = 51;
            this.CzlonkowieDGV.RowTemplate.Height = 24;
            this.CzlonkowieDGV.Size = new System.Drawing.Size(561, 339);
            this.CzlonkowieDGV.TabIndex = 45;
            this.CzlonkowieDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CzlonkowieDGV_CellContentClick);
            // 
            // Usun
            // 
            this.Usun.BackColor = System.Drawing.Color.Gray;
            this.Usun.FlatAppearance.BorderSize = 0;
            this.Usun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Usun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Usun.Location = new System.Drawing.Point(274, 433);
            this.Usun.Margin = new System.Windows.Forms.Padding(2);
            this.Usun.Name = "Usun";
            this.Usun.Size = new System.Drawing.Size(76, 28);
            this.Usun.TabIndex = 46;
            this.Usun.Text = "Usuń";
            this.Usun.UseVisualStyleBackColor = false;
            this.Usun.Click += new System.EventHandler(this.Usun_Click);
            // 
            // Usuńzmień
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 470);
            this.Controls.Add(this.Usun);
            this.Controls.Add(this.CzlonkowieDGV);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PlatnoscTb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.BmiCb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PlecCb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.WiekTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ObwodTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.WagaTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NameTb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Usuńzmień";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Usuńzmień";
            this.Load += new System.EventHandler(this.Usuńzmień_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CzlonkowieDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox PlatnoscTb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox BmiCb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox PlecCb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox WiekTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ObwodTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox WagaTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NameTb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView CzlonkowieDGV;
        private System.Windows.Forms.Button Usun;
    }
}